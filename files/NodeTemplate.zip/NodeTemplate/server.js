import express from "express";
import http from "http";
import { Server } from "socket.io";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, ".")));

let players = {};
let coins = [];
let obstacles = [];
const coinCount = 10; // Number of coins to spawn
const obstacleCount = 5; // Number of obstacles to spawn
const gameDuration = 60; // Game duration in seconds
let gameTime = gameDuration;
let gameActive = false;
let timerInterval;

function generateCoins() {
    coins = [];
    for (let i = 0; i < coinCount; i++) {
        coins.push({
            id: i,
            x: Math.random() * 18 - 9, // Random position within the ground size
            z: Math.random() * 18 - 9,
            collected: false
        });
    }
    io.emit('updateCoins', coins);
}

function generateObstacles() {
    obstacles = [];
    for (let i = 0; i < obstacleCount; i++) {
        obstacles.push({
            id: i,
            x: Math.random() * 16 - 8, // Slightly smaller range to avoid edges
            z: Math.random() * 16 - 8
        });
    }
    io.emit('updateObstacles', obstacles);
}

function startGameTimer() {
    if (!gameActive && Object.keys(players).length > 0) {
        gameActive = true;
        gameTime = gameDuration;
        io.emit('updateTimer', gameTime);
        timerInterval = setInterval(() => {
            gameTime--;
            io.emit('updateTimer', gameTime);
            if (gameTime <= 0) {
                clearInterval(timerInterval);
                gameActive = false;
                determineWinner();
            }
        }, 1000);
    }
}

function determineWinner() {
    let winner = null;
    let highestScore = -1;
    for (let id in players) {
        if (players[id].score > highestScore) {
            highestScore = players[id].score;
            winner = id;
        }
    }
    io.emit('gameEnd', {
        winnerId: winner,
        winnerScore: highestScore
    });
}

io.on('connection', (socket) => {
    console.log('A player connected:', socket.id);

    // Initialize a new player
    players[socket.id] = {
        id: socket.id,
        x: Math.random() * 10 - 5,
        z: Math.random() * 10 - 5,
        score: 0,
        health: 100 // Starting health for each player
    };

    // Send current game state to the new player
    socket.emit('init', {
        playerId: socket.id,
        players: players,
        coins: coins,
        obstacles: obstacles,
        timeLeft: gameTime
    });

    // Broadcast new player to others
    socket.broadcast.emit('newPlayer', players[socket.id]);

    // Start the game timer if not already started
    startGameTimer();

    // Handle player movement
    socket.on('updatePosition', (position) => {
        if (players[socket.id]) {
            players[socket.id].x = position.x;
            players[socket.id].z = position.z;
            socket.broadcast.emit('updatePlayer', players[socket.id]);
        }
    });

    // Handle coin collection
    socket.on('collectCoin', (coinId) => {
        const coin = coins.find(c => c.id === coinId && !c.collected);
        if (coin) {
            coin.collected = true;
            players[socket.id].score += 1;
            io.emit('updateCoins', coins);
            io.emit('updateScore', { id: socket.id, score: players[socket.id].score });
        }
    });

    // Handle obstacle collision
    socket.on('hitObstacle', () => {
        if (players[socket.id]) {
            players[socket.id].health = Math.max(0, players[socket.id].health - 10); // Reduce health by 10
            io.emit('updateHealth', { id: socket.id, health: players[socket.id].health });
            if (players[socket.id].health <= 0) {
                socket.emit('gameOver');
            }
        }
    });

    // Handle disconnection
    socket.on('disconnect', () => {
        console.log('A player disconnected:', socket.id);
        delete players[socket.id];
        socket.broadcast.emit('removePlayer', socket.id);
        if (Object.keys(players).length === 0 && gameActive) {
            clearInterval(timerInterval);
            gameActive = false;
        }
    });
});

// Start the game with initial coins and obstacles
generateCoins();
generateObstacles();

server.listen(3000, () => {
    console.log("Game running on http://localhost:3000");
});