import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,          // Set the fixed port to 5173
    strictPort: true,    // Force Vite to fail if the port is already in use
    allowedHosts: [
      'aigamef.gameonworld.ai', // Allow this specific host
      'localhost',              // You can also allow localhost
      '127.0.0.1'               // Allow local IP
    ],
    open: true,          // Optionally, open the browser automatically
  }
})
