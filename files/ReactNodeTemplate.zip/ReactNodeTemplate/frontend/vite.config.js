import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,          // Set the fixed port to 5173
    strictPort: true,    // Force Vite to fail if the port is already in use
    open: true,          // Optionally, open the browser automatically
  }
})
