// logicofgame.js

export class GameManager {
  constructor(broadcastCallback) {
    // Rooms and broadcast are managed externally (server)
    this.rooms = new Map();
    this.broadcast = broadcastCallback; // function(room, message)
  }

  // --- Initial State ---
  static INITIAL_SNAKES = [
    {
      id: 1,
      name: "Player 1",
      body: [{ x: 5, y: 5 }],
      dir: { x: 1, y: 0 },
      score: 0,
    },
    {
      id: 2,
      name: "Player 2",
      body: [{ x: 15, y: 15 }],
      dir: { x: -1, y: 0 },
      score: 0,
    },
  ];

  // --- Utility methods ---
  generateFoodPosition(grid, snakes) {
    const occupied = new Set();
    for (const snake of snakes) {
      for (const seg of snake.body) {
        occupied.add(`${seg.x},${seg.y}`);
      }
    }
    let x, y;
    do {
      x = Math.floor(Math.random() * grid);
      y = Math.floor(Math.random() * grid);
    } while (occupied.has(`${x},${y}`));
    return { x, y };
  }

  createGameState() {
    const grid = 20;
    const snakes = GameManager.INITIAL_SNAKES.map((snake) => ({
      ...snake,
      body: [{ ...snake.body[0] }],
      dir: { ...snake.dir },
    }));
    return {
      grid,
      snakes,
      food: this.generateFoodPosition(grid, snakes),
      timer: 60,
      countdown: 3,
    };
  }

  getWinner(state) {
    const [p1, p2] = state.snakes;
    if (p1.score > p2.score) return `${p1.name} wins with ${p1.score} points!`;
    if (p2.score > p1.score) return `${p2.name} wins with ${p2.score} points!`;
    return `It's a tie! Both players have ${p1.score} points.`;
  }

  updateGameState(state) {
    const newHeads = state.snakes.map((snake) => ({
      id: snake.id,
      head: {
        x: snake.body[0].x + snake.dir.x,
        y: snake.body[0].y + snake.dir.y,
      },
    }));

    // --- Head collision ---
    if (
      newHeads.length === 2 &&
      newHeads[0].head.x === newHeads[1].head.x &&
      newHeads[0].head.y === newHeads[1].head.y
    ) {
      state.snakes.forEach((snake) => {
        const initial = GameManager.INITIAL_SNAKES.find(
          (s) => s.id === snake.id
        );
        snake.body = [{ x: initial.body[0].x, y: initial.body[0].y }];
        snake.dir = { ...initial.dir };
      });
      return;
    }

    // --- Regular movement ---
    for (const snake of state.snakes) {
      const head = { ...snake.body[0] };
      head.x = (head.x + snake.dir.x + state.grid) % state.grid;
      head.y = (head.y + snake.dir.y + state.grid) % state.grid;
      snake.body.unshift(head);

      // Eat food
      if (head.x === state.food.x && head.y === state.food.y) {
        snake.score++;
        state.food = this.generateFoodPosition(state.grid, state.snakes);
      } else {
        snake.body.pop();
      }

      // Bite another snake
      for (const other of state.snakes) {
        if (other.id === snake.id) continue;
        for (const seg of other.body) {
          if (head.x === seg.x && head.y === seg.y) {
            other.score++;
            snake.score = 0;
            const initial1 = GameManager.INITIAL_SNAKES.find(
              (s) => s.id === snake.id
            );
            const initial2 = GameManager.INITIAL_SNAKES.find(
              (s) => s.id === other.id
            );
            snake.body = [{ ...initial1.body[0] }];
            snake.dir = { ...initial1.dir };
            other.body = [{ ...initial2.body[0] }];
            other.dir = { ...initial2.dir };
            return;
          }
        }
      }
    }
  }

  // --- Room / Game Flow Management ---
  createRoom(gameSessionUuid) {
    this.rooms.set(gameSessionUuid, {
      players: new Map(),
      state: this.createGameState(),
    });
    return this.rooms.get(gameSessionUuid);
  }

  addPlayer(gameSessionUuid, playerUuid, ws) {
    if (!this.rooms.has(gameSessionUuid)) {
      this.createRoom(gameSessionUuid);
    }
    const room = this.rooms.get(gameSessionUuid);
    room.players.set(playerUuid, ws);
    return room;
  }

  removePlayer(gameSessionUuid, playerUuid) {
    const room = this.rooms.get(gameSessionUuid);
    if (!room) return;
    room.players.delete(playerUuid);
    if (room.players.size === 0) {
      this.rooms.delete(gameSessionUuid);
    }
  }

  startCountdown(room) {
    const interval = setInterval(() => {
      room.state.countdown = Math.max(0, room.state.countdown - 1);
      this.broadcast(room, { type: "state", data: room.state });

      if (room.state.countdown <= 0) {
        clearInterval(interval);
        this.startGameLoop(room);
      }
      if (room.players.size < 2) {
        clearInterval(interval);
        this.broadcast(room, { type: "gameStopped" });
      }
    }, 1000);
  }

  startGameLoop(room) {
    const interval = setInterval(() => {
      this.updateGameState(room.state);
      this.broadcast(room, { type: "state", data: room.state });
      room.state.timer = Math.max(0, room.state.timer - 0.2);

      if (room.state.timer <= 0 || room.players.size < 2) {
        clearInterval(interval);
        const result = this.getWinner(room.state);
        this.broadcast(room, { type: "gameOver", message: result });
        this.broadcast(room, { type: "gameStopped" });
      }
    }, 200);
  }
}
