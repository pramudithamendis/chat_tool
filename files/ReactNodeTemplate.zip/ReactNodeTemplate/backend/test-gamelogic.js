// Test the separated game logic
import {
  GameManager,
  createSnake,
  randomCell,
  GRID_SIZE,
} from "./gamelogic.js";

console.log("Testing separated game logic...");

// Test basic functions
console.log("Grid size:", GRID_SIZE);
console.log("Random cell:", randomCell());

// Test snake creation
const snake = createSnake(5, 10, 1, 0, "#34d399");
console.log("Created snake:", snake);

// Test GameManager (mock io object)
const mockIo = {
  to: (room) => ({
    emit: (event, data) => {
      console.log(`Mock emit to room ${room}:`, event, data);
    },
  }),
};

const gameManager = new GameManager(mockIo);
console.log("GameManager created");

// Test game creation
const game = gameManager.createGame("test-game-123");
console.log("Game created:", {
  id: game.id,
  name: game.name,
  gridSize: game.state.grid,
  hasApple: !!game.state.apple,
  snakesCount: Object.keys(game.state.snakes).length,
});

// Test player direction handling
game.state.players["socket-123"] = 1; // Assign socket to player 1
const directionResult = gameManager.handlePlayerDirection(
  "test-game-123",
  "socket-123",
  { x: 0, y: -1 }
);
console.log("Direction change result:", directionResult);
console.log("Snake 1 pending direction:", game.state.snakes[1].pendingDir);

// Clean up
gameManager.removeGame("test-game-123");

console.log("✅ Game logic separation test completed successfully!");
