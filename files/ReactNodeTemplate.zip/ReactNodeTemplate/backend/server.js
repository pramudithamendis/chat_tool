import express from "express";
import http from "http";
import { WebSocketServer } from "ws";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import Room from "./schemas/roomSchema.js";
import { fileURLToPath } from "url";
import { v4 as uuidv4 } from "uuid";
// import { GameManager } from "./gamelogic.js";
import { GameManager } from "./logicofgame.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const ws = new WebSocketServer({ server });
const PORT = process.env.GAME_PORT || 8087;
// const gameManager = new GameManager(ws);
app.use(cors());
app.use(express.json());
// app.use(express.static(path.join(__dirname, "../frontend")));

const rooms = new Map();

function broadcast(room, message) {
  const json = JSON.stringify(message);
  for (const [, playerWs] of room.players) {
    if (playerWs.readyState === 1) playerWs.send(json);
  }
}

const gameManager = new GameManager(broadcast);

app.post("/api/createRoom", async (req, res) => {
  try {
    const { room, players } = req.body;
    const id = uuidv4();

    // Create a new Room model instance
    const newRoom = new Room({
      gameSessionUuid: room?.gameSessionUuid || id,
      name: room?.name || `Snake Room ${id.slice(0, 4)}`,
      players: players || [],
    });

    // Save to database
    // await newRoom.save();

    // Create a new game instance
    // const game = gameManager.createGame(newRoom.gameSessionUuid);

    const frontend = process.env.FRONTEND_URL;
    const link1 = `${frontend}/?gameSessionUuid=${newRoom.gameSessionUuid}&gameStateId=${newRoom._id}&uuid=${players?.[0]?.uuid || ""}`;
    const link2 = `${frontend}/?gameSessionUuid=${newRoom.gameSessionUuid}&gameStateId=${newRoom._id}&uuid=${players?.[1]?.uuid || ""}`;
    return res.json({
      status: true,
      message: "success",
      payload: {
        gameSessionUuid: newRoom.gameSessionUuid,
        gameStateId: newRoom._id,
        name: newRoom.name,
        createDate: newRoom.createdDate,
        link1,
        link2,
      },
    });
  } catch (err) {
    console.error("createRoom error", err);
    return res.status(500).json({ status: false, message: "Server error" });
  }
});

// --- WebSocket Events ---
ws.on("connection", (ws) => {
  ws.on("message", (msg) => {
    try {
      const data = JSON.parse(msg);

      switch (data.type) {
        case "joinGame": {
          const { gameSessionUuid, playerUuid } = data;
          const room = gameManager.addPlayer(gameSessionUuid, playerUuid, ws);
          ws.roomId = gameSessionUuid;
          ws.playerUuid = playerUuid;

          const playerNum = room.players.size + 1;
          ws.send(
            JSON.stringify({
              type: "joined",
              role: "player",
              playerNum,
              data: room.state,
            })
          );
          if (room.players.size === 2) {
            broadcast(room, { type: "gameStarted" });
            gameManager.startCountdown(room);
          }
          break;
        }
        case "dir": {
          const room = gameManager.rooms.get(ws.roomId);
          if (!room) return;
          const snakeIndex = [...room.players.keys()].indexOf(ws.playerUuid);
          const snake = room.state.snakes[snakeIndex];
          const newDir = data.data;
          if (newDir && !(newDir.x === -snake.dir.x && newDir.y === -snake.dir.y)) {
            snake.dir = newDir;
          }
          break;
        }
      }
    } catch (err) {
      console.error("Message error:", err);
      ws.send(JSON.stringify({ type: "error", message: "Invalid message" }));
    }
  });

  ws.on("close", () => {
    if (ws.roomId && rooms.has(ws.roomId)) {
      const room = rooms.get(ws.roomId);
      room.players.delete(ws.playerUuid);
      if (room.players.size === 0) {
        rooms.delete(ws.roomId);
      } else {
        broadcast(room, { type: "gameStopped" });
      }
    }
  });
});

// --- Start Server ---
server.listen(PORT, () => {
  console.log(`✅ WebSocket server running on http://localhost:${PORT}`);
});
