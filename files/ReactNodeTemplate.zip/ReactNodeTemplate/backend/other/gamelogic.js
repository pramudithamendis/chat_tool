// Game Logic for Snake Game
const GRID_SIZE = 20;
const TICK_MS = 200; // Game tick interval in milliseconds

export function randomCell() {
  return {
    x: Math.floor(Math.random() * GRID_SIZE),
    y: Math.floor(Math.random() * GRID_SIZE),
  };
}

export function createSnake(startX, startY, dx, dy, color) {
  return {
    alive: true,
    dir: { x: dx, y: dy },
    pendingDir: { x: dx, y: dy },
    body: [{ x: startX, y: startY }],
    grow: 0,
    color,
    score: 0,
  };
}

export function createNewGame(id) {
  const state = {
    grid: GRID_SIZE,
    apple: randomCell(),
    players: {},
    snakes: {
      1: createSnake(5, 10, 1, 0, "#34d399"),
      2: createSnake(15, 10, -1, 0, "#60a5fa"),
    },
    spectators: new Set(),
    gameStatus: "waiting", // 'waiting', 'active', 'finished'
    requiredPlayers: 2,
  };

  // Place apple away from initial snake positions
  placeAppleAwayFromSnakes(state);

  // Don't start tick immediately - will be started when game becomes active
  return {
    id,
    name: `Room ${id}`,
    createdDate: new Date().toISOString(),
    state,
    tick: null, // Will be set when game starts
  };
}

export function placeAppleAwayFromSnakes(gameState) {
  if (!gameState) return;
  let attempts = 0;
  while (attempts < 100) {
    // Prevent infinite loops
    const c = randomCell();
    const occupied = Object.values(gameState.snakes).some(
      (s) => s && s.body && s.body.some((p) => p.x === c.x && p.y === c.y)
    );
    if (!occupied) {
      gameState.apple = c;
      return;
    }
    attempts++;
  }
  // If we can't find a free spot, just place it anywhere
  gameState.apple = randomCell();
}

export function stepSnake(snake, gameState) {
  if (!snake.alive || !gameState) return;

  // Apply pendingDir if not reversing
  const ndx = snake.pendingDir.x;
  const ndy = snake.pendingDir.y;
  const cdx = snake.dir.x;
  const cdy = snake.dir.y;

  if (!(ndx === -cdx && ndy === -cdy)) {
    snake.dir = { x: ndx, y: ndy };
  }

  const head = snake.body[0];
  const nx = head.x + snake.dir.x;
  const ny = head.y + snake.dir.y;
  const newHead = { x: nx, y: ny };

  // Wall collision - use gameState.grid or default to GRID_SIZE
  const gridSize = gameState.grid || GRID_SIZE;
  if (nx < 0 || ny < 0 || nx >= gridSize || ny >= gridSize) {
    snake.alive = false;
    return;
  }

  // Self collision
  if (snake.body.some((p) => p.x === nx && p.y === ny)) {
    snake.alive = false;
    return;
  }

  // Move snake
  snake.body.unshift(newHead);
  if (snake.grow > 0) {
    snake.grow--;
  } else {
    snake.body.pop();
  }

  // Check apple collision
  if (gameState.apple && nx === gameState.apple.x && ny === gameState.apple.y) {
    snake.grow += 2;
    snake.score += 1;
    placeAppleAwayFromSnakes(gameState);
  }
}

export function checkSnakeVsSnake(a, b) {
  if (
    !a.alive ||
    !b.alive ||
    !a.body ||
    !b.body ||
    a.body.length === 0 ||
    b.body.length === 0
  )
    return;

  const headA = a.body[0];

  // Check if snake A hits snake B's body (excluding head)
  if (
    b.body.some((p, idx) => idx !== 0 && p.x === headA.x && p.y === headA.y)
  ) {
    a.alive = false;
  }

  // Head-on collision (both snakes die)
  if (headA.x === b.body[0].x && headA.y === b.body[0].y) {
    a.alive = false;
    b.alive = false;
  }
}

export function resetGame(gameState) {
  if (!gameState) return;

  gameState.snakes[1] = createSnake(5, 10, 1, 0, "#34d399");
  gameState.snakes[2] = createSnake(15, 10, -1, 0, "#60a5fa");
  placeAppleAwayFromSnakes(gameState);
}

// Game tick function - to be called by external game manager
let gameTickCallback = null;

export function setGameTickCallback(callback) {
  gameTickCallback = callback;
}

export function gameTick(roomId, gameState, io, games) {
  const game = games.get(roomId);
  if (!game) {
    console.log(`GameTick: No game found for room ${roomId}`);
    return;
  }

  const state = gameState || game.state;
  const { snakes } = state;

  // Only tick if game is active
  if (state.gameStatus !== "active") {
    return; // Game not active, don't run game logic
  }

  // Only tick if we have players connected
  const connectedPlayers = Object.keys(state.players).length;
  if (connectedPlayers === 0) {
    return; // No players, don't run game logic
  }

  // Update snakes
  if (snakes[1]) stepSnake(snakes[1], state);
  if (snakes[2]) stepSnake(snakes[2], state);

  // Check collisions between snakes
  if (snakes[1] && snakes[2]) {
    checkSnakeVsSnake(snakes[1], snakes[2]);
    checkSnakeVsSnake(snakes[2], snakes[1]);
  }

  // Emit state to all clients in this room
  if (io) {
    io.to(roomId).emit("state", {
      grid: state.grid,
      apple: state.apple,
      snakes,
    });
  }

  // Reset game if both snakes are dead
  const bothDead =
    (!snakes[1] || !snakes[1].alive) && (!snakes[2] || !snakes[2].alive);
  if (bothDead) {
    setTimeout(() => resetGame(state), 1000);
  }
}

// Game manager class for better organization
export class GameManager {
  constructor(io) {
    this.games = new Map();
    this.io = io;
  }

  createGame(id) {
    const gameData = createNewGame(id);

    // Don't start tick immediately - will be started when enough players join
    this.games.set(id, gameData);
    console.log(`Created new game: ${id} (waiting for players)`);
    return gameData;
  }

  startGame(id) {
    const game = this.games.get(id);
    if (!game) return false;

    if (game.state.gameStatus === "waiting") {
      game.state.gameStatus = "active";

      // Start the game tick
      game.tick = setInterval(() => {
        gameTick(id, game.state, this.io, this.games);
      }, TICK_MS);

      console.log(`Game ${id} started!`);

      // Notify all players that the game has started
      this.io.to(id).emit("gameStarted", {
        message: "Game has started!",
        gameState: {
          grid: game.state.grid,
          apple: game.state.apple,
          snakes: game.state.snakes,
          status: "active",
        },
      });

      return true;
    }
    return false;
  }

  stopGame(id) {
    const game = this.games.get(id);
    if (!game) return false;

    if (game.tick) {
      clearInterval(game.tick);
      game.tick = null;
    }

    game.state.gameStatus = "finished";
    console.log(`Game ${id} stopped`);

    this.io.to(id).emit("gameStopped", {
      message: "Game has ended",
      gameState: {
        grid: game.state.grid,
        apple: game.state.apple,
        snakes: game.state.snakes,
        status: "finished",
      },
    });

    return true;
  }

  checkAndStartGame(roomId) {
    const game = this.games.get(roomId);
    if (!game) return false;

    const connectedPlayers = Object.keys(game.state.players).length;
    const requiredPlayers = game.state.requiredPlayers;

    console.log(
      `Game ${roomId}: ${connectedPlayers}/${requiredPlayers} players connected`
    );

    if (
      connectedPlayers >= requiredPlayers &&
      game.state.gameStatus === "waiting"
    ) {
      this.startGame(roomId);
      return true;
    }

    return false;
  }

  getGame(id) {
    return this.games.get(id);
  }

  removeGame(id) {
    const game = this.games.get(id);
    if (game && game.tick) {
      clearInterval(game.tick);
    }
    this.games.delete(id);
    console.log(`Removed game: ${id}`);
  }

  getAllGames() {
    return this.games;
  }

  // Handle player direction change
  handlePlayerDirection(roomId, socketId, direction) {
    const game = this.games.get(roomId);
    if (!game) return false;

    const state = game.state;
    const playerNum = state.players[socketId];
    if (!playerNum) return false;

    const snake = state.snakes[playerNum];
    if (snake && snake.alive) {
      snake.pendingDir = direction;
      return true;
    }
    return false;
  }

  // Get room for a specific socket
  getPlayerRoom(socketId) {
    for (const [roomId, game] of this.games) {
      if (game.state.players[socketId]) {
        return roomId;
      }
    }
    return null;
  }
}

export { GRID_SIZE, TICK_MS };
