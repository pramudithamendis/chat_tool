import mongoose from "mongoose";
const { Schema } = mongoose;

const playerSchema = new Schema({
  name: { type: String, required: true },
  uuid: { type: String, required: true },
  profileImage: { type: String, required: false },
  ready: { type: Boolean, default: false },
  winState: { type: String, default: "DEFEATED" },
});

const roomSchema = new Schema(
  {
    gameSessionUuid: { type: String, required: true, unique: true },
    name: { type: String, required: false },
    players: { type: [playerSchema], default: [] },
    createdDate: { type: Date, default: Date.now },
    gameStatus: {
      type: String,
      default: "ACTIVE",
      enum: ["ACTIVE", "FINISHED", "DROPPED", "DRAW"],
    },
    gameType: {
      type: String,
      default: "MULTIPLAYER",
      enum: ["MULTIPLAYER", "BOT_GAME"],
    },
    winnerSent: { type: Boolean, default: false },
  },
  { collection: "snake_game_rooms" }
);

const Room = mongoose.model("Room", roomSchema);
export default Room;
